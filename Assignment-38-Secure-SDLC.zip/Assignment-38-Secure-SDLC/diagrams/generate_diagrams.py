"""Generates the three diagrams used in the Assignment 38 report.

Usage:  pip install matplotlib   then   python generate_diagrams.py
The PNG files are written next to this script.
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, FancyArrowPatch
import os

OUT = os.path.dirname(os.path.abspath(__file__))
plt.rcParams['font.family'] = ['Liberation Sans', 'DejaVu Sans']
NAVY = '#1F3864'

def box(ax, x, y, w, h, text, fc='#EEF2F8', ec=NAVY, fs=10, bold=True, lw=1.4, ls='-'):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.4,rounding_size=1.2', fc=fc, ec=ec, lw=lw, ls=ls))
    ax.text(x + w/2, y + h/2, text, ha='center', va='center', fontsize=fs, fontweight='bold' if bold else 'normal', color='#111', linespacing=1.25)

def arrow(ax, p1, p2, color='#333', ls='-', rad=0.0, lw=1.4):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle='-|>', mutation_scale=13, color=color, lw=lw, ls=ls,
                                 connectionstyle=f'arc3,rad={rad}'))

# ---------- Figure 1: phases ----------
fig, ax = plt.subplots(figsize=(7.4, 4.6), dpi=200)
ax.set_xlim(0, 100); ax.set_ylim(-4, 62); ax.axis('off')
phases = [
 ('1. Requirements', 'Classify data\nAbuse cases\nCompliance needs'),
 ('2. Design', 'Threat model (STRIDE)\nSecure design review\nAuth design'),
 ('3. Coding', 'Secure coding rules\nPeer review + SAST\nNo secrets in code'),
 ('4. Testing', 'SAST / DAST / SCA\nSecurity test cases\nQuality Gate'),
 ('5. Deployment', 'Secrets manager\nHardened containers\nGated release'),
 ('6. Maintenance', 'Patching\nMonitoring\nIncident response'),
]
w, h = 26, 11
xs = [4, 37, 70]
for i, (t, d) in enumerate(phases):
    row, col = divmod(i, 3)
    x = xs[col]; y = 47 - row * 32
    box(ax, x, y, w, h, t, fc='#D9E2F3', fs=11)
    ax.add_patch(Rectangle((x - 0.4, y - 13.2), w + 0.8, 11.6, fc='white', ec='#9AA7BD', lw=1))
    ax.text(x + w/2, y - 7.4, d, ha='center', va='center', fontsize=8.6, color='#222', linespacing=1.5)
for row in range(2):
    y = 47 - row * 32 + h/2
    arrow(ax, (xs[0] + w + 0.8, y), (xs[1] - 0.8, y))
    arrow(ax, (xs[1] + w + 0.8, y), (xs[2] - 0.8, y))
# elbow 3 -> 4
yb = 47 - 13.2          # bottom of description box (row 1)
yt = 47 - 32 + h + 0.6  # top of row-2 box
ym = (yb + yt) / 2
ax.plot([xs[2] + w/2, xs[2] + w/2], [yb - 0.4, ym], color='#333', lw=1.4)
ax.plot([xs[2] + w/2, xs[0] + w/2], [ym, ym], color='#333', lw=1.4)
ax.plot([xs[0] + w/2, xs[0] + w/2], [ym, yt + 1.6], color='#333', lw=1.4)
arrow(ax, (xs[0] + w/2, yt + 2.2), (xs[0] + w/2, yt + 0.2))
# loop back note
ax.text(50, -2.2, 'Findings from maintenance feed back into requirements for the next release', ha='center', fontsize=8.5, style='italic', color='#444')
fig.savefig(os.path.join(OUT, 'secure-sdlc-phases.png'), bbox_inches='tight', facecolor='white'); plt.close(fig)

# ---------- Figure 2: DFD ----------
fig, ax = plt.subplots(figsize=(7.4, 4.4), dpi=200)
ax.set_xlim(0, 100); ax.set_ylim(-7, 60); ax.axis('off')
# trust boundary
ax.add_patch(Rectangle((36, 4), 37, 52, fc='#FFF8EC', ec='#C0504D', lw=1.6, ls=(0, (5, 3))))
ax.text(54.5, 53, 'Trust boundary: our servers', ha='center', fontsize=9, color='#C0504D', fontweight='bold')
# external entities
box(ax, 2, 24, 18, 11, 'Customer\n(browser)', fc='#E8F0E3', ec='#3C6E2F', fs=10)
box(ax, 86, 24, 13, 11, 'Payment\ngateway', fc='#E8F0E3', ec='#3C6E2F', fs=10)
# process
ax.add_patch(Circle((55, 30), 11, fc='#D9E2F3', ec=NAVY, lw=1.6))
ax.text(55, 30, 'Payment\nweb app + API', ha='center', va='center', fontsize=10, fontweight='bold')
# data store
ax.plot([40, 70], [10, 10], color=NAVY, lw=1.8); ax.plot([40, 70], [16, 16], color=NAVY, lw=1.8)
ax.text(55, 13, 'Orders database', ha='center', va='center', fontsize=10, fontweight='bold')
# flows
arrow(ax, (22, 31), (43.2, 31))
ax.text(29, 33.2, '1  login +\ncard details', ha='center', fontsize=8, linespacing=1.2)
arrow(ax, (43.2, 27), (22, 27))
ax.text(29, 22.8, '4  receipt', ha='center', fontsize=8)
arrow(ax, (66, 33), (84.5, 33))
ax.text(78.7, 35.3, '2  payment\nrequest', ha='center', fontsize=8, linespacing=1.2)
arrow(ax, (84.5, 27), (66, 27))
ax.text(78.7, 22.8, '3  result', ha='center', fontsize=8)
arrow(ax, (52, 18.6), (52, 16.4))
arrow(ax, (58, 16.4), (58, 18.6))
ax.text(50.5, 17.9, '5  read / write', fontsize=8, ha='right')
# STRIDE tags
def tag(x, y, t):
    ax.text(x, y, t, ha='center', va='center', fontsize=8, color='white', fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.25', fc='#C0504D', ec='none'))
tag(11, 39, 'S  R'); tag(29, 41.5, 'T  I'); tag(55, 44.5, 'D  E'); tag(68, 7, 'T  I'); tag(92.5, 39, 'S')
ax.text(2, -2.5, 'Red tags = STRIDE threats: S Spoofing, T Tampering, R Repudiation,\nI Information disclosure, D Denial of service, E Elevation of privilege',
        fontsize=7.8, color='#444', va='center', linespacing=1.4)
fig.savefig(os.path.join(OUT, 'payment-dfd-stride.png'), bbox_inches='tight', facecolor='white'); plt.close(fig)

# ---------- Figure 3: pipeline ----------
fig, ax = plt.subplots(figsize=(7.4, 3.9), dpi=200)
ax.set_xlim(0, 100); ax.set_ylim(0, 54); ax.axis('off')
GREY, ORG = '#EDEDED', '#FBE0C3'
row1 = [('Commit +\nPull Request', GREY), ('Build', GREY), ('Unit tests', GREY), ('SAST +\nsecret scan', ORG), ('Dependency\n+ image scan', ORG)]
bw, bh = 15.2, 10
x0s = [1.5 + i * 19.6 for i in range(5)]
for (t, c), x in zip(row1, x0s):
    box(ax, x, 38, bw, bh, t, fc=c, fs=9, ec='#555' if c == GREY else '#C07A1E')
for i in range(4):
    arrow(ax, (x0s[i] + bw + 0.6, 43), (x0s[i + 1] - 0.6, 43))
row2 = [('Deploy to\nstaging', GREY), ('Smoke test +\nDAST (ZAP)', ORG), ('Manual\napproval', GREY), ('Deploy to\nproduction', '#D5E8D0')]
for (t, c), x in zip(row2, x0s[:4]):
    box(ax, x, 16, bw, bh, t, fc=c, fs=9, ec='#555' if c == GREY else ('#C07A1E' if c == ORG else '#3C6E2F'))
for i in range(3):
    arrow(ax, (x0s[i] + bw + 0.6, 21), (x0s[i + 1] - 0.6, 21))
# elbow from last of row1 to first of row2
xe = x0s[4] + bw/2
ax.plot([xe, xe], [37, 32], color='#333', lw=1.4)
ax.plot([xe, x0s[0] + bw/2], [32, 32], color='#333', lw=1.4)
ax.plot([x0s[0] + bw/2, x0s[0] + bw/2], [32, 28.5], color='#333', lw=1.4)
arrow(ax, (x0s[0] + bw/2, 29.5), (x0s[0] + bw/2, 27.3))
# note
ax.add_patch(FancyBboxPatch((78.6, 14), 20.4, 14, boxstyle='round,pad=0.3,rounding_size=1', fc='#FBE3E1', ec='#C0504D', lw=1.3, ls=(0, (4, 2))))
ax.text(88.8, 21, 'If any gate fails,\nthe pipeline stops\nand the developer\ngets the report', ha='center', va='center', fontsize=7.8, color='#7A1F1B', linespacing=1.3)
# legend
ax.add_patch(Rectangle((2, 3), 3.2, 3, fc=ORG, ec='#C07A1E')); ax.text(6.3, 4.5, 'Security gate', va='center', fontsize=8.5)
ax.add_patch(Rectangle((26, 3), 3.2, 3, fc=GREY, ec='#555')); ax.text(30.3, 4.5, 'Normal stage', va='center', fontsize=8.5)
ax.add_patch(Rectangle((48, 3), 3.2, 3, fc='#D5E8D0', ec='#3C6E2F')); ax.text(52.3, 4.5, 'Release', va='center', fontsize=8.5)
fig.savefig(os.path.join(OUT, 'cicd-security-pipeline.png'), bbox_inches='tight', facecolor='white'); plt.close(fig)


print('Diagrams written to', OUT)

# Assignment 38: Secure SDLC Policy

**Name:** Anshu
**Roll number:** 24WU0101163
**University:** Woxsen University (B.Tech)
**Course:** Industry SDLC (PBL), Security module

This repository holds my report and the code that goes with it. The report is a Secure SDLC policy with a security checklist for each phase of the SDLC (requirements, design, coding, testing, deployment and maintenance). The small demos show that some of the key rules really work.

## What is in this repo

| Path | What it is |
|------|------------|
| `Secure-SDLC-Policy.pdf` / `.docx` | The full report (Word and PDF versions) |
| `demos/` | Five small Node.js demos (see below) |
| `diagrams/` | The three diagrams used in the report, plus the Python script that draws them |
| `screenshots/` | Terminal output of each demo, as used in the report |
| `Jenkinsfile` | Sample CI/CD pipeline showing where the security gates go (not run on a real Jenkins server) |
| `package.json`, `package-lock.json` | Node.js dependencies (`bcryptjs`, `pino`) |
| `.gitignore` | Keeps `node_modules` and secrets out of the repo |

## Demos

| File | What it shows |
|------|---------------|
| `demos/sql.js` | SQL injection with a string-joined query, and the fix using a parameterized query |
| `demos/hash.js` | Password hashing and checking with bcrypt |
| `demos/redact_before.js` | A log line that leaks a password, token and card number |
| `demos/redact.js` | The same log line with those fields redacted |
| `demos/config.js` | The app refuses to start when required config is missing |

## How to run

You need Node.js 22 or newer.

```bash
npm install
node demos/sql.js
node demos/hash.js
node demos/redact_before.js
node demos/redact.js
node demos/config.js        # exits with code 1 because DB_URL and JWT_SECRET are not set
```

To see the config check pass, set the two variables first:

```bash
DB_URL=sqlite://test JWT_SECRET=example node demos/config.js
```

Node may print an `ExperimentalWarning` for `node:sqlite` when running `sql.js`. It is harmless.

## Re-drawing the diagrams

```bash
pip install matplotlib
python diagrams/generate_diagrams.py
```

## Notes

- All data in the demos is made up (fake users, fake card number, fake passwords).
- Never commit real secrets. `.env` files are listed in `.gitignore`.

const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(':memory:');
db.exec("CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT, role TEXT)");
db.exec("INSERT INTO users (email, role) VALUES ('anshu@example.com','student'), ('admin@example.com','admin')");

const input = "x' OR '1'='1";   // attacker input

// BAD: string concatenation
const bad = db.prepare("SELECT email, role FROM users WHERE email = '" + input + "'").all();
console.log("Vulnerable query returned", bad.length, "rows:", JSON.stringify(bad));

// GOOD: parameterized query
const good = db.prepare("SELECT email, role FROM users WHERE email = ?").all(input);
console.log("Parameterized query returned", good.length, "rows");

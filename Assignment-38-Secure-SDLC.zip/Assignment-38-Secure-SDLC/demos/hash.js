const bcrypt = require('bcryptjs');
(async () => {
  const password = 'Summer@2026';
  const hash = await bcrypt.hash(password, 10);
  console.log('Stored in DB :', hash);
  console.log('Right password:', await bcrypt.compare(password, hash));
  console.log('Wrong password:', await bcrypt.compare('summer@2026', hash));
})();

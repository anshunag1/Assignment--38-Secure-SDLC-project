const pino = require('pino');
const log = pino({ base: null, timestamp: false });
log.info({ user: 'anshu', password: 'Summer@2026', token: 'eyJhbGciOi...', card: { number: '4111111111111111' } }, 'login attempt');

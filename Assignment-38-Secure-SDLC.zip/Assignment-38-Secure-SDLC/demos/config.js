const required = ['DB_URL', 'JWT_SECRET'];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error('Missing required config: ' + missing.join(', '));
  process.exit(1);
}
console.log('Config OK, starting server');
